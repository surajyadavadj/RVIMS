let map;

let marker;
// STM32 
function loadSTM32() {
    fetch("/api/stm32?_=" + Date.now())   // cache avoid
        .then(r => r.json())
        .then(d => {

            document.getElementById("stm32-data").innerHTML =
                `<b>Event:</b> ${d.event}<br>
                 <b>Latitude:</b> ${d.lat}<br>
                 <b>Longitude:</b> ${d.lon}<br>
                 <b>Date:</b> ${d.date}<br>
                 <b>Time:</b> ${d.time}`;

            updateMap(d.lat, d.lon, "STM32 Event");
        });
}

//   MAP
function updateMap(lat, lon, text) {

    lat = parseFloat(lat);
    lon = parseFloat(lon);

    if (!map) {
        map = L.map('map').setView([lat, lon], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap'
        }).addTo(map);

        marker = L.marker([lat, lon]).addTo(map).bindPopup(text);
    } else {
        marker.setLatLng([lat, lon]);
        marker.setPopupContent(text);
        map.panTo([lat, lon]);
    }
}

//  AUTO REFRESH 
setInterval(loadSTM32, 1000);   //  every 1 second


//  ESP32 
function loadESP32() {
    fetch("/api/esp32")
        .then(r => r.json())
        .then(list => {
            if (list.length === 0) return;

            initMap(list[0].lat, list[0].lon, "ESP32 Image");

            let g = document.getElementById("gallery");
            g.innerHTML = "";

            list.forEach(i => {
                let img = document.createElement("img");
                img.src = "images/" + i.image + "?t=" + Date.now();

                img.className = "thumb";
                g.appendChild(img);

                L.marker([i.lat, i.lon])
                 .addTo(map)
                 .bindPopup(i.time);
            });
        });
}

//  MAP 
function initMap(lat, lon, text) {
    map = L.map('map').setView([lat, lon], 15);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap'
    }).addTo(map);

    L.marker([lat, lon]).addTo(map).bindPopup(text);
}
